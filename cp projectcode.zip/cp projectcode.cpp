#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <windows.h>
#include <vector>
using namespace std;

// ====== Constants ======
const int MAX_STUDENTS = 50;
const int MAX_DAYS = 30;

// ====== Color Utilities ======
void setColor(int textColor, int bgColor = 15) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), (bgColor << 4) | textColor);
}
void printHeader(string text)
{
    setColor(1); cout << "\n====================================\n       " << text << "\n====================================\n"; setColor(0);
}
void printSuccess(string text)
{
    setColor(10); cout << text << endl; setColor(0);
}
void printError(string text)
{
    setColor(12); cout << text << endl; setColor(0);
}
void printWarning(string text)
{
    setColor(8); cout << text << endl; setColor(0);
}

// ====== Welcome Screen ======
void welcomeScreen() {
    setColor(13);
    cout << "\n========================================\n";
    cout << "   WELCOME TO STUDENT MANAGEMENT SYSTEM\n";
    cout << "========================================\n\n";
    setColor(0);
    cout << "Loading ";
    for (int i = 0; i < 20; i++)
    {
        cout << "."; Sleep(100);
    }
    cout << "\n\n";
}

// ====== Student Class ======
class Student {
public:
    int roll;
    string name;
    int marks[3];
    float average;
    char grade;
    bool attendance[MAX_DAYS]{ false };

    Student(int r, string n, int m1, int m2, int m3)
    {
        roll = r; name = n; marks[0] = m1; marks[1] = m2; marks[2] = m3;
        calculateAverageGrade();
    }

    void calculateAverageGrade() {
        int totalMarks = marks[0] + marks[1] + marks[2];
        average = totalMarks / 3.0;
        if (average >= 85) grade = 'A';
        else if (average >= 70) grade = 'B';
        else if (average >= 50) grade = 'C';
        else grade = 'F';
    }

    float totalMarks()
    {
        return marks[0] + marks[1] + marks[2];
    }
    float GPA()
    {
        return (totalMarks() / 300.0f) * 4.0f;
    }
    float attendancePercentage(int totalDays)
    {
        int present = 0;
        for (int i = 0; i < totalDays; i++)
            if (attendance[i])
                present++;
        return (totalDays > 0) ? (present * 100.0f) / totalDays : 0; //ternery operator
    }
};
void clearInput() {
    cin.clear();
    cin.ignore(10000, '\n');
}
bool isValidName(const string& name)
{
    for (char c : name) // rANGE BASED FOR LOOP
    {
        if (!isalpha(c) && c != ' ')  // only letters and space allowed, isalpha builtin function to cctype library
            return false;
    }
    return true;
}
// ====== Student Manager Class ======
class StudentManager {
private:
    vector<Student> students;
    int totalAttendanceDays = 0;

public:
    void addStudent() {
        if (students.size() >= MAX_STUDENTS)
        {
            printError("Cannot add more students!");
            return;
        }
        int roll;
        while (true) {
            cout << "Enter Roll Number: ";
            cin >> roll;
            if (cin.fail()) { clearInput(); printError("Invalid input! Enter a number."); continue; }

            bool exists = false;
            for (auto& s : students)
                if (s.roll == roll) { exists = true; break; }

            if (exists) { printError("Roll number exists!"); continue; }

            break; // valid roll
        }
        cin.ignore();
        string name;
        while (true) {
            cout << "Enter Name: ";
            getline(cin, name);
            if (isValidName(name)) break;
            printError("Invalid Name! Only letters and spaces allowed.");
        }
        int m[3];
        for (int i = 0; i < 3; i++) {
            while (true) {
                cout << "Enter marks for Subject " << i + 1 << ": ";
                cin >> m[i];
                if (cin.fail()) { clearInput(); printError("Invalid Input! Enter a number."); continue; }
                if (m[i] < 0 || m[i] > 100) { printError("Marks must be 0-100!"); continue; }
                break; // valid marks
            }
        }
        students.emplace_back(roll, name, m[0], m[1], m[2]);
        printSuccess("Student added!");
    }

    void viewAllStudents() {
        if (students.empty())
        {
            printWarning("No student records!"); return;
        }
        printHeader("ALL STUDENT RECORDS");
        cout << left << setw(5) << "No" << setw(10) << "Roll" << setw(20) << "Name"
            << setw(10) << "Sub1" << setw(10) << "Sub2" << setw(10) << "Sub3"
            << setw(10) << "Total" << setw(10) << "Average" << setw(8) << "Grade"
            << setw(6) << "GPA" << setw(12) << "Attendance(%)" << endl;
        cout << "--------------------------------------------------------------------------------------------------------------\n";

        int idxNum = 1;
        for (auto& s : students)
        {
            float attPercent = s.attendancePercentage(totalAttendanceDays);
            cout << setw(5) << idxNum++ << setw(10) << s.roll << setw(20) << s.name
                << setw(10) << s.marks[0] << setw(10) << s.marks[1] << setw(10) << s.marks[2]
                << setw(10) << s.totalMarks() << setw(10) << s.average;

            if (s.grade == 'F') setColor(12);
            else setColor(10);
            cout << setw(8) << s.grade; setColor(0);
            cout << setw(6) << fixed << setprecision(2) << s.GPA();

            if (attPercent < 75) setColor(12);
            else setColor(10);
            cout << setw(12) << attPercent; setColor(0);

            cout << endl;
        }
    }

    void searchStudent() {
        if (students.empty())
        {
            printWarning("No students!"); return;
        }
        int roll;
        while (true) {
            cout << "Enter Roll Number: ";
            cin >> roll;
            if (cin.fail()) { clearInput(); printError("Invalid Input! Enter a number."); continue; }
            break; // valid number
        }
        int idx = -1;
        for (int i = 0; i < students.size(); i++)
            if (students[i].roll == roll)
            {
                idx = i; break;
            }
        if (idx == -1) { printError("Student not found!"); return; }

        Student& s = students[idx];
        printHeader("STUDENT DETAILS");
        cout << left << setw(10) << "Roll" << setw(20) << "Name" << setw(10) << "Sub1" << setw(10) << "Sub2" << setw(10) << "Sub3"
            << setw(10) << "Total" << setw(10) << "Average" << setw(8) << "Grade"
            << setw(6) << "GPA" << setw(12) << "Attendance(%)" << endl;
        cout << "---------------------------------------------------------------------------------------------\n";

        float attPercent = s.attendancePercentage(totalAttendanceDays);
        cout << setw(10) << s.roll << setw(20) << s.name << setw(10) << s.marks[0] << setw(10) << s.marks[1]
            << setw(10) << s.marks[2] << setw(10) << s.totalMarks() << setw(10) << s.average;

        if (s.grade == 'F') setColor(12); else setColor(10);
        cout << setw(8) << s.grade; setColor(0);

        cout << setw(6) << fixed << setprecision(2) << s.GPA();

        if (attPercent < 75) setColor(14);
        cout << setw(12) << attPercent; setColor(0);

        cout << endl;
    }

    void updateMarks() {
        if (students.empty()) { printWarning("No students!"); return; }
        int roll;
        cout << "Enter Roll Number to update: ";
        cin >> roll;
        int idx = -1;
        for (int i = 0; i < students.size(); i++)
            if (students[i].roll == roll)
            {
                idx = i; break;
            }
        if (idx == -1) { printError("Student not found!"); return; }

        for (int i = 0; i < 3; i++) {
            while (true) {
                cout << "Enter new marks for Subject " << i + 1 << ": ";
                cin >> students[idx].marks[i];
                if (cin.fail()) { clearInput(); printError("Invalid Input! Enter a number."); continue; }
                if (students[idx].marks[i] < 0 || students[idx].marks[i] > 100) { printError("Marks must be 0-100!"); continue; }
                break; // valid marks
            }
        }
        students[idx].calculateAverageGrade();
        printSuccess("Marks updated successfully!");
    }

    void deleteStudent() {
        if (students.empty()) { printWarning("No students!"); return; }
        int roll;
        while (true) {
            cout << "Enter Roll Number to delete: ";
            cin >> roll;
            if (cin.fail()) { clearInput(); printError("Invalid Input! Enter a number."); continue; }
            break; // valid number
        }
        int idx = -1;
        for (int i = 0; i < students.size(); i++)
            if (students[i].roll == roll)
            {
                idx = i; break;
            }
        if (idx == -1) { printError("Student not found!"); return; }
        students.erase(students.begin() + idx); // &student[0] + idx of student the user wants to delete so it moves fromidx 0 to that student, erases it and moves all index one place to left
        printSuccess("Student deleted successfully!");
    }

    void top3Students() {
        if (students.size() < 3) { printWarning("Less than 3 students!"); return; }
        vector<int> idxs(students.size()); // declaring  vector array "idxs" of typr int same size at students vector array 
        for (int i = 0; i < students.size(); i++)
            idxs[i] = i; //filling indexes with numbers 
        for (int i = 0; i < students.size() - 1; i++) // bubble sort 
            for (int j = 0; j < students.size() - i - 1; j++)
                if (students[idxs[j]].average < students[idxs[j + 1]].average)
                    swap(idxs[j], idxs[j + 1]); // sorting indexes not numbers

        printHeader("TOP 3 STUDENTS");
        for (int i = 0; i < 3; i++) {
            Student& s = students[idxs[i]];
            cout << i + 1 << ". " << s.name << " | Roll: " << s.roll << " | Avg: " << s.average << " | Grade: " << s.grade << endl;
        }
    }
    void passFailSummary() {
        int countA = 0, countB = 0, countC = 0, countF = 0;
        printHeader("PASS/FAIL SUMMARY");
        for (auto& s : students) {
            switch (s.grade) {
            case 'A': countA++; break;
            case 'B': countB++; break;
            case 'C': countC++; break;
            case 'F': countF++; break;
            }
        }
        cout << "A:" << countA << " B:" << countB << " C:" << countC << " F:" << countF << endl;
        if (countF > 0) {
            printError("Students Failed:");
            cout << "Total Failed:" << countF << endl;
            for (auto& s : students) if (s.grade == 'F') cout << s.name << " | Roll:" << s.roll << endl;
        }
        int passed = countA + countB + countC;
        if (passed > 0) {
            printSuccess("Students Passed:");
            cout << "Total Passed:" << passed << endl;
            for (auto& s : students) if (s.grade != 'F') cout << s.name << " | Roll:" << s.roll << endl;
        }
    }
    void markAttendance() {
        if (students.empty()) { printWarning("No students!"); return; }
        if (totalAttendanceDays >= MAX_DAYS) { printWarning("Max attendance days reached!"); return; }
        cout << "\nMarking attendance for Day " << totalAttendanceDays + 1 << " (P=Present, A=Absent)\n";
        for (auto& s : students)
        {
            char status;
            while (true)
            {
                cout << s.name << ": ";
                cin >> status;
                status = toupper(status);
                if (status == 'P' || status == 'A') break;
                printError("Invalid Input! Enter 'P' or 'A'.");
                clearInput();
            }
            s.attendance[totalAttendanceDays] = (status == 'P');
        }
        totalAttendanceDays++;
        printSuccess("Attendance marked!");
    }

    void displayAttendance() {
        if (students.empty()) { printWarning("No students!"); return; }
        int roll;
        while (true) {
            cout << "Enter Roll Number: ";
            cin >> roll;
            if (cin.fail()) { clearInput(); printError("Invalid Input! Enter a number."); continue; }
            break; // valid number
        }
        int idx = -1;
        for (int i = 0; i < students.size(); i++)
            if (students[i].roll == roll)
            {
                idx = i; break;
            }
        if (idx == -1) { printError("Student not found!"); return; }
        Student& s = students[idx];
        printHeader("ATTENDANCE RECORD");
        for (int d = 0; d < totalAttendanceDays; d++)
            cout << "Day " << d + 1 << ": " << (s.attendance[d] ? "Present" : "Absent") << endl;
    }

    void attendanceReport() {
        if (students.empty()) { printWarning("No students!"); return; }
        printHeader("ATTENDANCE PERCENTAGE REPORT");
        for (auto& s : students) {
            float percent = s.attendancePercentage(totalAttendanceDays);
            if (percent < 75) setColor(14);
            cout << s.name << " | Roll: " << s.roll << " | Attendance: " << percent << "%" << endl;
            setColor(0);
        }
    }

    void exportReport() {
        ofstream file("student_report.txt");
        if (!file) { printError("Cannot open file!"); return; }
        file << left << setw(10) << "Roll" << setw(20) << "Name" << setw(10) << "Sub1" << setw(10) << "Sub2" << setw(10) << "Sub3"
            << setw(10) << "Total" << setw(10) << "Average" << setw(8) << "Grade" << setw(12) << "Attendance(%)" << endl;
        file << "-----------------------------------------------------------------------------------------\n";
        for (auto& s : students) {
            float attPercent = s.attendancePercentage(totalAttendanceDays);
            file << setw(10) << s.roll << setw(20) << s.name << setw(10) << s.marks[0] << setw(10) << s.marks[1] << setw(10) << s.marks[2]
                << setw(10) << s.totalMarks() << setw(10) << s.average << setw(8) << s.grade << setw(12) << attPercent << endl;
        }
        file.close();
        printSuccess("Report exported!");
    }
};

// ====== Main Menu ======
void mainMenu(StudentManager& manager) {
    while (true) {
        setColor(11);
        cout << "\n================ MAIN MENU ================\n";
        setColor(0);
        cout << "1. Add Student\n2. View All Students\n3. Search Student\n4. Update Marks\n5. Delete Student\n6. Top 3 Students\n7. Pass/Fail Summary\n8. Mark Daily Attendance\n9. Display Attendance of a Student\n10. Attendance Report\n11. Export Report\n12. Exit\n";
        int choice;
        while (true) {
            cout << "\nEnter your choice: ";
            cin >> choice;
            if (cin.fail()) {
                clearInput();   // Clear the error state
                printError("Invalid input! Numbers only.");
                continue;       // Go back to asking for input
            }
            if (choice < 1 || choice > 12) {
                printError("Invalid choice! Enter 1-12.");
                continue;
            }
            break;  // Valid input, exit the loop
        }
        switch (choice) {
        case 1: manager.addStudent(); break;
        case 2: manager.viewAllStudents(); break;
        case 3: manager.searchStudent(); break;
        case 4: manager.updateMarks(); break;
        case 5: manager.deleteStudent(); break;
        case 6: manager.top3Students(); break;
        case 7: manager.passFailSummary(); break;
        case 8: manager.markAttendance(); break;
        case 9: manager.displayAttendance(); break;
        case 10: manager.attendanceReport(); break;
        case 11: manager.exportReport(); break;
        case 12: printSuccess("Exiting..."); return;
        default: printError("Invalid choice!"); break;
            if (cin.fail()) {
                clearInput();
                printError("Invalid Input! Please enter a number.");
                return;
            }
        }
        cout << "\nPress Enter to continue..."; cin.ignore(); cin.get();
    }
}
// ====== Main ======
int main() {
    system("color F0");
    welcomeScreen();
    StudentManager manager;
    mainMenu(manager);
    return 0;
}
// THE END ... THANK YOU!